/**
 * character.js - Quản lý nhân vật: nâng cấp, hiển thị chi tiết
 */

const CharacterManager = {
    currentSelectedChar: null,

    /**
     * Nâng cấp nhân vật lên 1 level
     */
    upgradeCharacter(instanceId) {
        const char = Game.state.characters[instanceId];
        if (!char) return { success: false, message: 'Không tìm thấy nhân vật!' };

        if (char.level >= GameData.config.maxCharLevel) {
            return { success: false, message: 'Nhân vật đã đạt cấp độ tối đa!' };
        }

        const cost = Utils.getUpgradeCost(char.level);
        const resources = Game.state.player.resources;

        if (resources.vpnc < cost.vpnc || resources.gold < cost.gold) {
            return { 
                success: false, 
                message: `Không đủ vật phẩm! Cần ${Utils.formatNumber(cost.vpnc)} VPNC và ${Utils.formatNumber(cost.gold)} Vàng` 
            };
        }

        // Trừ vật phẩm
        resources.vpnc -= cost.vpnc;
        resources.gold -= cost.gold;

        // Tăng level và cập nhật chỉ số
        char.level++;
        char.currentStats = Game.calculateStats(char.baseStats, char.level, char);

        Game.save();
        return { 
            success: true, 
            message: `Nâng cấp thành công lên LV ${char.level}!`,
            char: char
        };
    },

    /**
     * Lấy danh sách kỹ năng và trạng thái mở khoá
     */
    getSkillsWithUnlockStatus(char) {
        const skills = char.skills;
        const unlockLevels = GameData.config.unlockLevels;
        const result = [];

        // Đánh thường - luôn mở
        result.push({
            key: 'basic',
            ...skills.basic,
            unlocked: true,
            category: 'basic'
        });

        // Kỹ năng chủ động - luôn mở
        result.push({
            key: 'active',
            ...skills.active,
            unlocked: true,
            category: 'active'
        });

        // Bị động 1
        if (skills.passive1) {
            result.push({
                key: 'passive1',
                ...skills.passive1,
                unlocked: char.level >= unlockLevels.passive1,
                unlockLevel: unlockLevels.passive1,
                category: 'passive'
            });
        }

        // Bị động 2
        if (skills.passive2) {
            result.push({
                key: 'passive2',
                ...skills.passive2,
                unlocked: char.level >= unlockLevels.passive2,
                unlockLevel: unlockLevels.passive2,
                category: 'passive'
            });
        }

        // Thần chú
        if (char.hasDivine) {
            if (skills.divine1) {
                result.push({
                    key: 'divine1',
                    ...skills.divine1,
                    unlocked: char.level >= unlockLevels.divine1,
                    unlockLevel: unlockLevels.divine1,
                    category: 'divine'
                });
            }
            if (skills.divine2) {
                result.push({
                    key: 'divine2',
                    ...skills.divine2,
                    unlocked: char.level >= unlockLevels.divine2,
                    unlockLevel: unlockLevels.divine2,
                    category: 'divine'
                });
            }
        }

        return result;
    },

    /**
     * Kiểm tra kỹ năng có mở khoá không
     */
    isSkillUnlocked(char, skillKey) {
        const unlockLevels = GameData.config.unlockLevels;
        const levelMap = {
            basic: 0,
            active: 0,
            passive1: unlockLevels.passive1,
            passive2: unlockLevels.passive2,
            divine1: unlockLevels.divine1,
            divine2: unlockLevels.divine2
        };
        return char.level >= (levelMap[skillKey] || 0);
    },

    /**
     * Lấy bonus bạo kích từ thần chú
     */
    getCritBonus(char) {
        let critRate = GameData.config.baseCritRate;
        let critMultiplier = GameData.config.baseCritMultiplier;

        if (char.hasDivine && char.level >= GameData.config.unlockLevels.divine2) {
            const divine2 = char.skills.divine2;
            if (divine2.critBonus) critRate += divine2.critBonus;
            if (divine2.critDmgBonus) critMultiplier += divine2.critDmgBonus;
        }

        return { critRate, critMultiplier };
    },

    /**
     * Lấy bonus xuyên giáp
     */
    getArmorPierce(char) {
        let pierce = 0;
        if (char.hasDivine && char.level >= GameData.config.unlockLevels.divine2) {
            const divine2 = char.skills.divine2;
            if (divine2.armorPierce) pierce += divine2.armorPierce;
        }
        return pierce;
    },

    /**
     * Lấy bonus sát thương từ bị động 2 Vegito
     */
    getDamageBonus(char) {
        let bonus = 0;
        if (char.id === 'vegito' && char.level >= GameData.config.unlockLevels.passive2) {
            const passive2 = char.skills.passive2;
            if (passive2.damageBonus) bonus += passive2.damageBonus;
        }
        return bonus;
    },

    /**
     * Lấy bonus hồi máu từ thần chú 2 Whis
     */
    getHealBonus(char) {
        let bonus = 0;
        if (char.hasDivine && char.level >= GameData.config.unlockLevels.divine2) {
            const divine2 = char.skills.divine2;
            if (divine2.healBonus) bonus += divine2.healBonus;
        }
        return bonus;
    },

    /**
     * Lấy bonus sát thương chảy máu+ từ thần chú 1 Vegito
     */
    getBleeding2Bonus(char) {
        let bonus = 0;
        if (char.hasDivine && char.level >= GameData.config.unlockLevels.divine1) {
            const divine1 = char.skills.divine1;
            if (divine1.bleeding2Bonus) bonus += divine1.bleeding2Bonus;
        }
        return bonus;
    },

    /**
     * Render danh sách nhân vật cho màn hình quản lý
     */
    renderCharacterList() {
        const container = document.getElementById('charList');
        if (!container) return;

        container.innerHTML = '';
        const chars = Object.values(Game.state.characters);

        chars.forEach(char => {
            const item = document.createElement('div');
            item.className = 'char-list-item';
            if (this.currentSelectedChar === char.instanceId) {
                item.classList.add('active');
            }
            item.innerHTML = `
                <div class="char-name">${char.name}</div>
                <div class="char-level">
                    <span class="type-${char.type}">${Utils.getTypeName(char.type)}</span>
                    <span style="margin-left: 8px;">LV ${char.level}</span>
                </div>
            `;
            item.addEventListener('click', () => {
                this.currentSelectedChar = char.instanceId;
                this.renderCharacterList();
                this.renderCharacterDetail(char);
            });
            container.appendChild(item);
        });

        // Tự chọn nhân vật đầu tiên nếu chưa có
        if (!this.currentSelectedChar && chars.length > 0) {
            this.currentSelectedChar = chars[0].instanceId;
            this.renderCharacterDetail(chars[0]);
        }
    },

    /**
     * Render chi tiết nhân vật
     */
    renderCharacterDetail(char) {
        const container = document.getElementById('charDetailContent');
        if (!container || !char) return;

        const skills = this.getSkillsWithUnlockStatus(char);
        const cost = Utils.getUpgradeCost(char.level);
        const canUpgrade = char.level < GameData.config.maxCharLevel;
        const resources = Game.state.player.resources;
        const hasEnoughResources = resources.vpnc >= cost.vpnc && resources.gold >= cost.gold;

        let skillsHtml = '';
        skills.forEach(skill => {
            const unlockText = skill.unlocked 
                ? '<span class="skill-unlock" style="color: var(--success);">Đã mở khoá</span>'
                : `<span class="skill-unlock">Mở khoá LV ${skill.unlockLevel}</span>`;
            
            const categoryLabels = {
                basic: 'Đánh Thường',
                active: 'Kỹ Năng Chủ Động',
                passive: 'Bị Động',
                divine: 'Thần Chú'
            };

            skillsHtml += `
                <div class="skill-item ${skill.unlocked ? 'unlocked' : 'locked'}">
                    <div class="skill-header">
                        <span class="skill-name">${skill.name} <small style="color: var(--text-muted); font-weight: 400;">[${categoryLabels[skill.category]}]</small></span>
                        ${skill.unlockLevel ? unlockText : ''}
                    </div>
                    <div class="skill-desc">${skill.desc}</div>
                </div>
            `;
        });

        container.innerHTML = `
            <div class="char-header">
                <div class="char-header-info">
                    <h2><i class="${char.icon}"></i> ${char.name}</h2>
                    <span class="char-type type-${char.type}">${Utils.getTypeName(char.type)}</span>
                </div>
                <div class="char-level-display">
                    <div class="level-num">${char.level}</div>
                    <div class="level-max">/ ${GameData.config.maxCharLevel}</div>
                </div>
            </div>

            <div class="char-stats-grid">
                <div class="stat-item">
                    <div class="stat-label">HP</div>
                    <div class="stat-value">${Utils.formatNumber(char.currentStats.hp)}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">ATK</div>
                    <div class="stat-value">${char.currentStats.atk}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">DEF</div>
                    <div class="stat-value">${char.currentStats.def}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">SPD</div>
                    <div class="stat-value">${char.currentStats.spd}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">EN Tối Đa</div>
                    <div class="stat-value">${char.currentStats.en}</div>
                </div>
            </div>

            <div class="char-skills">
                <h4>Kỹ Năng</h4>
                ${skillsHtml}
            </div>

            ${canUpgrade ? `
            <div class="upgrade-section">
                <div class="upgrade-info">
                    <div>
                        <strong>Nâng cấp lên LV ${char.level + 1}</strong>
                    </div>
                    <div class="upgrade-cost">
                        <span><i class="ri-flashlight-fill" style="color: var(--vpnc);"></i> ${Utils.formatNumber(cost.vpnc)}</span>
                        <span><i class="ri-coin-fill" style="color: var(--gold);"></i> ${Utils.formatNumber(cost.gold)}</span>
                    </div>
                </div>
                <button class="btn btn-primary" style="width: 100%;" 
                    ${hasEnoughResources ? '' : 'disabled'}
                    onclick="CharacterManager.handleUpgrade('${char.instanceId}')">
                    <i class="ri-arrow-up-line"></i> Nâng Cấp
                </button>
                ${!hasEnoughResources ? '<p class="text-muted mt-1" style="font-size: 0.82rem;">Không đủ vật phẩm nâng cấp</p>' : ''}
            </div>
            ` : `
            <div class="upgrade-section text-center">
                <p style="color: var(--success); font-weight: 600;">
                    <i class="ri-star-fill"></i> Đã đạt cấp độ tối đa!
                </p>
            </div>
            `}
        `;
    },

    /**
     * Xử lý sự kiện nâng cấp
     */
    handleUpgrade(instanceId) {
        const result = this.upgradeCharacter(instanceId);
        UI.showMessage(result.message, result.success ? 'Thành Công' : 'Lỗi');
        
        if (result.success) {
            UI.updateResourceDisplay();
            this.renderCharacterList();
            this.renderCharacterDetail(result.char);
        }
    },

    /**
     * Render danh sách nhân vật cho chọn đội hình
     */
    renderTeamSelect() {
        const grid = document.getElementById('charGridTeam');
        const slots = document.getElementById('teamSlots');
        if (!grid || !slots) return;

        // Render slots
        slots.innerHTML = '';
        for (let i = 0; i < 3; i++) {
            const slot = document.createElement('div');
            slot.className = 'team-slot';
            const charId = Game.state.selectedTeam[i];
            
            if (charId) {
                const char = Game.state.characters[charId];
                if (char) {
                    slot.classList.add('filled');
                    slot.innerHTML = `
                        <div style="text-align: center;">
                            <i class="${char.icon}" style="font-size: 1.8rem; color: var(--accent-light);"></i>
                            <div style="font-weight: 600; font-size: 0.85rem; margin-top: 4px;">${char.name}</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted);">LV ${char.level}</div>
                        </div>
                    `;
                    slot.addEventListener('click', () => {
                        Game.state.selectedTeam.splice(i, 1);
                        this.renderTeamSelect();
                    });
                }
            } else {
                slot.innerHTML = `<span>Chỗ trống ${i + 1}</span>`;
            }
            slots.appendChild(slot);
        }

        // Render danh sách nhân vật
        grid.innerHTML = '';
        const chars = Object.values(Game.state.characters);
        
        chars.forEach(char => {
            const isSelected = Game.state.selectedTeam.includes(char.instanceId);
            const card = document.createElement('div');
            card.className = `char-card-mini ${isSelected ? 'selected' : ''}`;
            card.innerHTML = `
                <div class="char-name">${char.name}</div>
                <span class="char-type type-${char.type}">${Utils.getTypeName(char.type)}</span>
                <div class="char-stats">
                    LV ${char.level} | HP ${char.currentStats.hp} | ATK ${char.currentStats.atk}
                </div>
            `;
            
            card.addEventListener('click', () => {
                if (isSelected) {
                    const idx = Game.state.selectedTeam.indexOf(char.instanceId);
                    if (idx > -1) Game.state.selectedTeam.splice(idx, 1);
                } else if (Game.state.selectedTeam.length < 3) {
                    Game.state.selectedTeam.push(char.instanceId);
                }
                this.renderTeamSelect();
            });
            
            grid.appendChild(card);
        });
    }
};
