/**
 * ui.js - Quản lý giao diện, sự kiện, popup, hiển thị
 */

const UI = {
    init() {
        this.bindEvents();
        this.updateResourceDisplay();
        this.updatePlayerLevelDisplay();
        Game.showScreen('startScreen');
    },

    /**
     * Gắn các sự kiện
     */
    bindEvents() {
        // Start screen
        document.getElementById('startBtn').addEventListener('click', () => {
            Game.showScreen('mainScreen');
            this.updateResourceDisplay();
            this.updatePlayerLevelDisplay();
        });

        // Main menu buttons
        document.getElementById('btnStage').addEventListener('click', () => {
            StageManager.renderChapters();
            Game.showScreen('stageScreen');
        });

        document.getElementById('btnCharacter').addEventListener('click', () => {
            CharacterManager.currentSelectedChar = null;
            CharacterManager.renderCharacterList();
            Game.showScreen('characterScreen');
        });

        document.getElementById('btnEvent').addEventListener('click', () => {
            this.openPopup('eventPopup');
        });

        document.getElementById('btnGiftcode').addEventListener('click', () => {
            document.getElementById('giftcodeInput').value = '';
            document.getElementById('giftcodeMessage').textContent = '';
            this.openPopup('giftcodePopup');
        });

        document.getElementById('btnShop').addEventListener('click', () => {
            this.openPopup('shopPopup');
        });

        document.getElementById('btnReset').addEventListener('click', () => {
            this.openPopup('resetPopup');
        });

        // Back buttons
        document.getElementById('btnBackFromStage').addEventListener('click', () => {
            Game.showScreen('mainScreen');
        });

        document.getElementById('btnBackFromLevels').addEventListener('click', () => {
            StageManager.renderChapters();
            Game.showScreen('stageScreen');
        });

        document.getElementById('btnBackFromTeam').addEventListener('click', () => {
            StageManager.renderLevels();
            Game.showScreen('stageLevelsScreen');
        });

        document.getElementById('btnBackFromChar').addEventListener('click', () => {
            Game.showScreen('mainScreen');
        });

        // Start battle
        document.getElementById('btnStartBattle').addEventListener('click', () => {
            StageManager.startBattle();
        });

        // Giftcode
        document.getElementById('btnRedeemGiftcode').addEventListener('click', () => {
            const code = document.getElementById('giftcodeInput').value;
            const result = Game.redeemGiftcode(code);
            const msgEl = document.getElementById('giftcodeMessage');
            msgEl.textContent = result.message;
            msgEl.className = 'popup-message ' + (result.success ? 'success' : 'error');
            if (result.success) {
                this.updateResourceDisplay();
                document.getElementById('giftcodeInput').value = '';
            }
        });

        // Reset confirm
        document.getElementById('btnConfirmReset').addEventListener('click', () => {
            Game.reset();
            this.closePopup('resetPopup');
            this.updateResourceDisplay();
            this.updatePlayerLevelDisplay();
            Game.showScreen('mainScreen');
            this.showMessage('Đã đặt lại toàn bộ dữ liệu!', 'Thành Công');
        });

        // Battle result close
        document.getElementById('btnResultClose').addEventListener('click', () => {
            this.closePopup('battleResultPopup');
            Game.showScreen('mainScreen');
            this.updateResourceDisplay();
            this.updatePlayerLevelDisplay();
        });

        // Generic popup close buttons
        document.querySelectorAll('.popup-close-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const popupId = btn.dataset.popup;
                this.closePopup(popupId);
            });
        });

        // Click overlay to close popup
        document.querySelectorAll('.popup-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay && overlay.id !== 'battleResultPopup') {
                    this.closePopup(overlay.id);
                }
            });
        });
    },

    /**
     * Cập nhật hiển thị tài nguyên
     */
    updateResourceDisplay() {
        const res = Game.state.player.resources;
        document.getElementById('starLight').textContent = Utils.formatNumber(res.starLight);
        document.getElementById('diamond').textContent = Utils.formatNumber(res.diamond);
        document.getElementById('vpnc').textContent = Utils.formatNumber(res.vpnc);
        document.getElementById('gold').textContent = Utils.formatNumber(res.gold);
    },

    /**
     * Cập nhật hiển thị level người chơi
     */
    updatePlayerLevelDisplay() {
        const player = Game.state.player;
        document.getElementById('playerLevel').textContent = player.level;
        
        const expNeeded = Utils.getExpForLevel(player.level + 1);
        const expPercent = expNeeded > 0 ? (player.exp / expNeeded) * 100 : 0;
        document.getElementById('expFill').style.width = Math.min(100, expPercent) + '%';
    },

    /**
     * Mở popup
     */
    openPopup(popupId) {
        const popup = document.getElementById(popupId);
        if (popup) popup.classList.add('active');
    },

    /**
     * Đóng popup
     */
    closePopup(popupId) {
        const popup = document.getElementById(popupId);
        if (popup) popup.classList.remove('active');
    },

    /**
     * Hiển thị thông báo
     */
    showMessage(text, title = 'Thông Báo') {
        document.getElementById('messagePopupTitle').textContent = title;
        document.getElementById('messagePopupText').textContent = text;
        this.openPopup('messagePopup');
    },

    /**
     * Hiển thị kết quả trận đấu
     */
    showBattleResult(victory, battleState) {
        const popup = document.getElementById('battleResultPopup');
        const popupInner = popup.querySelector('.popup');
        const titleEl = document.getElementById('resultTitle');
        const contentEl = document.getElementById('resultContent');

        popupInner.classList.remove('victory', 'defeat');

        if (victory) {
            popupInner.classList.add('victory');
            titleEl.innerHTML = '<i class="ri-trophy-fill"></i> Chiến Thắng!';
            
            // Cập nhật tiến độ
            Game.updateProgress(battleState.chapterIndex, battleState.levelIndex);
            
            // Nhận phần thưởng
            const rewards = Game.getRewards();
            Game.state.player.resources.starLight += rewards.starLight;
            Game.state.player.resources.diamond += rewards.diamond;
            Game.state.player.resources.vpnc += rewards.vpnc;
            
            // Nhận EXP
            const stageIndex = battleState.chapterIndex * 10 + battleState.levelIndex;
            const expGained = Utils.getExpFromStage(stageIndex);
            const leveledUp = Game.addPlayerExp(expGained);
            
            Game.save();

            contentEl.innerHTML = `
                <p>Bạn đã chiến thắng!</p>
                <div class="result-rewards">
                    <div class="reward-item">
                        <i class="ri-star-fill" style="color: var(--star);"></i>
                        <div>
                            <div class="reward-value">+${Utils.formatNumber(rewards.starLight)}</div>
                            <div class="reward-label">Ánh Sao</div>
                        </div>
                    </div>
                    <div class="reward-item">
                        <i class="ri-diamond-fill" style="color: var(--diamond);"></i>
                        <div>
                            <div class="reward-value">+${Utils.formatNumber(rewards.diamond)}</div>
                            <div class="reward-label">Kim Cương</div>
                        </div>
                    </div>
                    <div class="reward-item">
                        <i class="ri-flashlight-fill" style="color: var(--vpnc);"></i>
                        <div>
                            <div class="reward-value">+${Utils.formatNumber(rewards.vpnc)}</div>
                            <div class="reward-label">VPNC</div>
                        </div>
                    </div>
                    <div class="reward-item">
                        <i class="ri-book-open-fill" style="color: var(--accent-light);"></i>
                        <div>
                            <div class="reward-value">+${Utils.formatNumber(expGained)}</div>
                            <div class="reward-label">Kinh Nghiệm</div>
                        </div>
                    </div>
                </div>
                ${leveledUp ? '<p style="margin-top: 16px; color: var(--success); font-weight: 600;"><i class="ri-arrow-up-circle-fill"></i> Chúc mừng! Bạn đã lên level!</p>' : ''}
            `;
        } else {
            popupInner.classList.add('defeat');
            titleEl.innerHTML = '<i class="ri-close-circle-fill"></i> Thất Bại';
            contentEl.innerHTML = `
                <p>Bạn đã thua trận này.</p>
                <p style="margin-top: 12px; color: var(--text-muted); font-size: 0.9rem;">
                    Hãy nâng cấp nhân vật hoặc thay đổi đội hình để thử lại!
                </p>
            `;
        }

        this.openPopup('battleResultPopup');
    },

    // ========== Battle UI ==========

    /**
     * Render toàn bộ giao diện trận đấu
     */
    renderBattle() {
        this.renderBattleUnits();
        document.getElementById('logContent').innerHTML = '';
    },

    /**
     * Render các đơn vị trên chiến trường
     */
    renderBattleUnits() {
        if (!BattleSystem.state) return;

        const playerContainer = document.getElementById('playerUnits');
        const enemyContainer = document.getElementById('enemyUnits');

        playerContainer.innerHTML = '';
        enemyContainer.innerHTML = '';

        BattleSystem.state.playerTeam.forEach(unit => {
            playerContainer.appendChild(this.createUnitElement(unit));
        });

        BattleSystem.state.enemyTeam.forEach(unit => {
            enemyContainer.appendChild(this.createUnitElement(unit));
        });
    },

    /**
     * Tạo element cho đơn vị
     */
    createUnitElement(unit) {
        const el = document.createElement('div');
        el.className = `battle-unit ${unit.isPlayer ? 'player-unit' : 'enemy-unit'}`;
        if (unit.isDead) el.classList.add('dead');

        // Đánh dấu lượt hiện tại
        const activeUnit = BattleSystem.turnOrder[BattleSystem.currentTurnIndex];
        if (activeUnit && activeUnit.id === unit.id && !unit.isDead) {
            el.classList.add('active-turn');
        }

        // Tính % HP
        const hpPercent = (unit.currentHp / unit.maxHp) * 100;
        const enPercent = (unit.currentEn / unit.maxEn) * 100;

        let hpClass = '';
        if (hpPercent <= 30) hpClass = 'low';
        else if (hpPercent <= 60) hpClass = 'medium';

        // Hiệu ứng trạng thái
        let effectsHtml = '';
        unit.effects.forEach(effect => {
            if (effect.type === 'shield' && effect.value > 0) {
                effectsHtml += `<span class="status-effect shield">🛡 ${Math.floor(effect.value)}</span>`;
            } else if (effect.type === 'burning' && effect.stacks > 0) {
                effectsHtml += `<span class="status-effect burning">🔥${effect.stacks}</span>`;
            } else if (effect.type === 'bleeding' && effect.stacks > 0) {
                effectsHtml += `<span class="status-effect bleeding">🩸${effect.stacks}</span>`;
            } else if (effect.type === 'bleeding2') {
                effectsHtml += `<span class="status-effect bleeding2">💔${effect.duration}</span>`;
            } else if (effect.type === 'destiny' && effect.stacks > 0) {
                effectsHtml += `<span class="status-effect destiny">☠${effect.stacks}</span>`;
            }
        });

        unit.buffs.forEach(buff => {
            if (buff.type === 'bloodrage') {
                effectsHtml += `<span class="status-effect bloodrage">⚡</span>`;
            } else if (buff.type === 'protect') {
                effectsHtml += `<span class="status-effect protect">✨${buff.duration}</span>`;
            } else if (buff.type === 'weaken') {
                effectsHtml += `<span class="status-effect weaken">⬇${buff.duration}</span>`;
            } else if (buff.type === 'atkUp') {
                effectsHtml += `<span class="status-effect atk-up">⚔${buff.duration}</span>`;
            }
        });

        el.innerHTML = `
            <div class="unit-avatar"><i class="${unit.icon}"></i></div>
            <div class="unit-name">${unit.name}</div>
            <span class="unit-type-badge type-${unit.type}">${Utils.getTypeName(unit.type)}</span>
            <div class="unit-hp-bar">
                <div class="unit-hp-fill ${hpClass}" style="width: ${hpPercent}%"></div>
            </div>
            <div class="unit-hp-text">${Utils.formatNumber(unit.currentHp)}/${Utils.formatNumber(unit.maxHp)}</div>
            <div class="unit-en-bar">
                <div class="unit-en-fill" style="width: ${enPercent}%"></div>
            </div>
            <div class="unit-en-text">EN ${unit.currentEn.toFixed(1)}/${unit.maxEn}</div>
            <div class="unit-status-effects">${effectsHtml}</div>
        `;

        // Click để chọn mục tiêu
        if (!unit.isPlayer && !unit.isDead) {
            el.addEventListener('click', () => {
                BattleSystem.handleUnitClick(unit);
            });
            el.style.cursor = 'pointer';
        }

        el.dataset.unitId = unit.id;
        return el;
    },

    /**
     * Cập nhật thông tin trận đấu
     */
    updateBattleInfo() {
        if (!BattleSystem.state) return;
        document.getElementById('battleStageInfo').textContent = BattleSystem.state.stageInfo;
        document.getElementById('battleTurnInfo').textContent = `Lượt ${BattleSystem.currentTurnIndex + 1}/${BattleSystem.turnOrder.length}`;
    },

    /**
     * Thêm entry vào log trận đấu
     */
    addBattleLogEntry(type, message) {
        const logContent = document.getElementById('logContent');
        if (!logContent) return;

        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;
        entry.textContent = message;
        logContent.appendChild(entry);
        logContent.scrollTop = logContent.scrollHeight;
    },

    /**
     * Hiển thị số sát thương nổi
     */
    showDamageNumber(unit, amount, type) {
        const unitEls = document.querySelectorAll('.battle-unit');
        let targetEl = null;
        
        unitEls.forEach(el => {
            if (el.dataset.unitId === unit.id) targetEl = el;
        });

        if (!targetEl) return;

        const dmgEl = document.createElement('div');
        dmgEl.className = `damage-number ${type}`;
        dmgEl.textContent = (type === 'heal' ? '+' : '-') + Utils.formatNumber(amount);
        dmgEl.style.left = '50%';
        dmgEl.style.top = '20%';
        dmgEl.style.transform = 'translateX(-50%)';
        
        targetEl.appendChild(dmgEl);
        
        setTimeout(() => dmgEl.remove(), 1000);
    },

    /**
     * Highlight các mục tiêu có thể chọn
     */
    highlightTargets(isPlayerAttacker) {
        const targets = isPlayerAttacker 
            ? document.querySelectorAll('.enemy-unit:not(.dead)')
            : document.querySelectorAll('.player-unit:not(.dead)');
        
        targets.forEach(el => el.classList.add('targeted'));
    },

    /**
     * Xóa highlight mục tiêu
     */
    clearTargetHighlights() {
        document.querySelectorAll('.battle-unit').forEach(el => {
            el.classList.remove('targeted');
        });
    }
};
