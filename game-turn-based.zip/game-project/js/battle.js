/**
 * battle.js - Logic chiến đấu Turn-Based
 */

const BattleSystem = {
    state: null,
    turnOrder: [],
    currentTurnIndex: 0,
    isProcessing: false,
    selectedSkill: null,
    waitingForTarget: false,
    battleEnded: false,

    /**
     * Khởi tạo trận đấu
     */
    init(config) {
        this.state = {
            playerTeam: config.playerTeam,
            enemyTeam: config.enemyTeam,
            chapterIndex: config.chapterIndex,
            levelIndex: config.levelIndex,
            stageInfo: config.stageInfo,
            turn: 1,
            log: []
        };
        this.turnOrder = [];
        this.currentTurnIndex = 0;
        this.battleEnded = false;
        this.selectedSkill = null;
        this.waitingForTarget = false;

        // Kích hoạt bị động đầu trận
        this.triggerBattleStartEffects();

        // Tính thứ tự đánh
        this.calculateTurnOrder();

        // Hiển thị ban đầu
        UI.renderBattle();
        UI.updateBattleInfo();
        this.addLog('system', `Trận đấu bắt đầu! ${config.stageInfo}`);

        // Bắt đầu lượt đầu tiên
        this.nextTurn();
    },

    /**
     * Kích hoạt các hiệu ứng đầu trận
     */
    triggerBattleStartEffects() {
        const allUnits = [...this.state.playerTeam, ...this.state.enemyTeam];
        
        allUnits.forEach(unit => {
            if (unit.isBot) return;

            const charId = unit.data.id;
            const charLevel = unit.data.level;

            // Omega Shenron Bị động 1: Hiệp 1 nhận khiên 100% HP
            if (charId === 'omega_shenron' && charLevel >= GameData.config.unlockLevels.passive1) {
                this.addShield(unit, unit.maxHp, 'passive');
                this.addLog('buff', `${unit.name} nhận khiên 100% HP từ Bị Động 1!`);
            }
        });
    },

    /**
     * Tính thứ tự đánh dựa trên SPD
     */
    calculateTurnOrder() {
        const allUnits = [...this.state.playerTeam, ...this.state.enemyTeam].filter(u => !u.isDead);
        allUnits.sort((a, b) => b.spd - a.spd);
        this.turnOrder = allUnits;
        this.currentTurnIndex = 0;
    },

    /**
     * Chuyển sang lượt tiếp theo
     */
    nextTurn() {
        if (this.battleEnded) return;

        // Kiểm tra kết thúc trận
        if (this.checkBattleEnd()) return;

        // Tìm đơn vị tiếp theo còn sống
        let attempts = 0;
        while (attempts < this.turnOrder.length) {
            const unit = this.turnOrder[this.currentTurnIndex];
            if (unit && !unit.isDead) {
                break;
            }
            this.currentTurnIndex = (this.currentTurnIndex + 1) % this.turnOrder.length;
            attempts++;
        }

        // Tính lại thứ tự nếu cần
        const aliveUnits = [...this.state.playerTeam, ...this.state.enemyTeam].filter(u => !u.isDead);
        if (aliveUnits.length === 0) return;

        const currentUnit = this.turnOrder[this.currentTurnIndex];
        if (!currentUnit || currentUnit.isDead) {
            this.calculateTurnOrder();
            this.currentTurnIndex = 0;
        }

        const activeUnit = this.turnOrder[this.currentTurnIndex];
        if (!activeUnit) return;

        activeUnit.turnCount++;

        // Xử lý đầu lượt: hiệu ứng dot, giảm thời gian buff
        this.processStartOfTurn(activeUnit);

        if (activeUnit.isDead) {
            this.currentTurnIndex = (this.currentTurnIndex + 1) % this.turnOrder.length;
            this.nextTurn();
            return;
        }

        // Kiểm tra bị động theo chu kỳ hiệp (Nhà Lữ Hành)
        this.checkTurnIntervalEffects(activeUnit);

        UI.updateBattleInfo();
        UI.renderBattleUnits();

        // Xử lý lượt
        if (activeUnit.isPlayer) {
            this.showSkillPanel(activeUnit);
        } else {
            this.executeBotTurn(activeUnit);
        }
    },

    /**
     * Xử lý đầu lượt
     */
    processStartOfTurn(unit) {
        // Xử lý hiệu ứng gây sát thương theo thời gian
        const effectsToRemove = [];
        
        unit.effects.forEach((effect, idx) => {
            if (effect.duration !== undefined && effect.duration !== 99) {
                effect.duration--;
                if (effect.duration <= 0) {
                    effectsToRemove.push(idx);
                }
            }

            // Rực lửa (đốt cháy)
            if (effect.type === 'burning' && effect.stacks > 0) {
                const dmg = Math.floor(unit.maxHp * effect.damagePerStack * effect.stacks);
                this.applyDamage(unit, dmg, null, true);
                this.addLog('damage', `${unit.name} bị ${Utils.getEffectName('burning')} (tầng ${effect.stacks}) gây ${dmg} sát thương!`);
                UI.showDamageNumber(unit, dmg, 'damage');
            }

            // Chảy máu thông thường
            if (effect.type === 'bleeding' && effect.stacks > 0) {
                const dmg = Math.floor(unit.maxHp * effect.damagePerStack * effect.stacks);
                this.applyDamage(unit, dmg, null, true);
                this.addLog('damage', `${unit.name} bị ${Utils.getEffectName('bleeding')} (tầng ${effect.stacks}) gây ${dmg} sát thương!`);
                UI.showDamageNumber(unit, dmg, 'damage');
            }

            // Chảy máu+ (Vegito)
            if (effect.type === 'bleeding2' && effect.source) {
                let dmg = Math.floor(effect.source.atk * effect.damagePercent);
                // Thần chú 1 Vegito tăng 10% ST chảy máu+
                if (effect.source.data && effect.source.data.id === 'vegito') {
                    const bonus = CharacterManager.getBleeding2Bonus(effect.source.data);
                    dmg = Math.floor(dmg * (1 + bonus));
                }
                this.applyDamage(unit, dmg, null, true);
                this.addLog('damage', `${unit.name} bị ${Utils.getEffectName('bleeding2')} gây ${dmg} sát thương!`);
                UI.showDamageNumber(unit, dmg, 'damage');
            }
        });

        // Xóa hiệu ứng hết hạn
        effectsToRemove.reverse().forEach(idx => unit.effects.splice(idx, 1));

        // Giảm thời gian buff
        unit.buffs = unit.buffs.filter(buff => {
            buff.duration--;
            return buff.duration > 0;
        });

        // Kiểm tra chết
        if (unit.currentHp <= 0) {
            unit.isDead = true;
            this.addLog('system', `${unit.name} đã ngã xuống!`);
        }
    },

    /**
     * Kiểm tra hiệu ứng theo chu kỳ hiệp
     */
    checkTurnIntervalEffects(unit) {
        if (unit.isBot) return;
        
        const charId = unit.data.id;
        const charLevel = unit.data.level;

        // Nhà Lữ Hành Bị động 1: Mỗi 2 hiệp nhận 2 EN
        if (charId === 'nha_ly_hanh' && charLevel >= GameData.config.unlockLevels.passive1) {
            if (unit.turnCount > 0 && unit.turnCount % 2 === 0) {
                unit.currentEn = Math.min(unit.maxEn, unit.currentEn + 2);
                this.addLog('buff', `${unit.name} nhận +2 EN từ Bị Động 1!`);
            }
        }
    },

    /**
     * Hiển thị bảng kỹ năng cho người chơi
     */
    showSkillPanel(unit) {
        const panel = document.getElementById('skillButtons');
        const nameEl = document.getElementById('activeCharName');
        const enEl = document.getElementById('activeCharEN');
        
        nameEl.textContent = unit.name;
        enEl.textContent = `EN: ${unit.currentEn.toFixed(1)}/${unit.maxEn}`;
        
        panel.innerHTML = '';

        // Đánh thường
        const basicBtn = document.createElement('button');
        basicBtn.className = 'skill-btn';
        basicBtn.innerHTML = `
            <div class="skill-btn-name">
                ${unit.data.skills.basic.name}
                <span class="skill-btn-en">+${unit.data.skills.basic.enGain} EN</span>
            </div>
            <div class="skill-btn-desc">${unit.data.skills.basic.desc}</div>
        `;
        basicBtn.addEventListener('click', () => this.selectSkill(unit, 'basic'));
        panel.appendChild(basicBtn);

        // Kỹ năng chủ động
        const activeSkill = unit.data.skills.active;
        const canUseActive = unit.currentEn >= activeSkill.enCost;
        
        const activeBtn = document.createElement('button');
        activeBtn.className = 'skill-btn';
        activeBtn.disabled = !canUseActive;
        activeBtn.innerHTML = `
            <div class="skill-btn-name">
                ${activeSkill.name}
                <span class="skill-btn-en">-${activeSkill.enCost} EN</span>
            </div>
            <div class="skill-btn-desc">${activeSkill.desc}</div>
        `;
        if (canUseActive) {
            activeBtn.addEventListener('click', () => this.selectSkill(unit, 'active'));
        }
        panel.appendChild(activeBtn);

        document.getElementById('currentTurnName').textContent = `Lượt của: ${unit.name}`;
    },

    /**
     * Chọn kỹ năng
     */
    selectSkill(unit, skillKey) {
        if (this.isProcessing) return;
        
        this.selectedSkill = { unit, skillKey };
        const skill = unit.data.skills[skillKey];
        
        // Xác định mục tiêu
        if (skill.type === 'aoe' || skill.type === 'healLowestAlly') {
            // AOE hoặc hồi máu đồng minh - không cần chọn mục tiêu
            this.executePlayerSkill(unit, skillKey, null);
        } else if (skill.type === 'lowestHP') {
            // Tìm mục tiêu HP thấp nhất ở đội địch
            const enemies = this.state.enemyTeam.filter(e => !e.isDead);
            if (enemies.length > 0) {
                enemies.sort((a, b) => a.currentHp - b.currentHp);
                this.executePlayerSkill(unit, skillKey, enemies[0]);
            }
        } else {
            // Đơn mục tiêu - cần người chơi chọn
            this.waitingForTarget = true;
            this.showTargetHint();
            UI.highlightTargets(unit.isPlayer);
        }
    },

    /**
     * Hiển thị gợi ý chọn mục tiêu
     */
    showTargetHint() {
        const panel = document.getElementById('skillButtons');
        const hint = document.createElement('div');
        hint.className = 'target-hint';
        hint.innerHTML = '<i class="ri-target-line"></i> Chọn mục tiêu kẻ địch để tấn công';
        panel.insertBefore(hint, panel.firstChild);
    },

    /**
     * Xử lý click vào đơn vị (chọn mục tiêu)
     */
    handleUnitClick(targetUnit) {
        if (!this.waitingForTarget || !this.selectedSkill) return;
        
        const attacker = this.selectedSkill.unit;
        
        // Chỉ cho phép chọn kẻ địch còn sống
        if (targetUnit.isDead || targetUnit.isPlayer === attacker.isPlayer) return;
        
        this.waitingForTarget = false;
        UI.clearTargetHighlights();
        this.executePlayerSkill(attacker, this.selectedSkill.skillKey, targetUnit);
    },

    /**
     * Thực thi kỹ năng người chơi
     */
    async executePlayerSkill(unit, skillKey, target) {
        this.isProcessing = true;
        document.getElementById('skillButtons').innerHTML = '<p class="text-muted">Đang thực thi...</p>';
        
        await Utils.delay(300);
        this.executeSkill(unit, skillKey, target);
        await Utils.delay(500);
        
        this.selectedSkill = null;
        this.isProcessing = false;
        
        if (!this.battleEnded) {
            this.currentTurnIndex = (this.currentTurnIndex + 1) % this.turnOrder.length;
            this.nextTurn();
        }
    },

    /**
     * Thực thi lượt bot
     */
    async executeBotTurn(unit) {
        this.isProcessing = true;
        document.getElementById('currentTurnName').textContent = `Lượt của: ${unit.name}`;
        document.getElementById('skillButtons').innerHTML = '<p class="text-muted">Đối phương đang hành động...</p>';
        
        await Utils.delay(600);
        
        // Bot AI: đủ EN thì dùng kỹ năng chủ động, không thì đánh thường
        const skillKey = unit.currentEn >= unit.data.skills.active.enCost ? 'active' : 'basic';
        const skill = unit.data.skills[skillKey];
        
        let target = null;
        if (skill.type === 'lowestHP') {
            const players = this.state.playerTeam.filter(p => !p.isDead);
            if (players.length > 0) {
                players.sort((a, b) => a.currentHp - b.currentHp);
                target = players[0];
            }
        } else if (skill.type !== 'aoe') {
            // Đơn mục tiêu: chọn người chơi HP thấp nhất
            const players = this.state.playerTeam.filter(p => !p.isDead);
            if (players.length > 0) {
                players.sort((a, b) => a.currentHp - b.currentHp);
                target = players[0];
            }
        }
        
        this.executeSkill(unit, skillKey, target);
        
        await Utils.delay(500);
        this.isProcessing = false;
        
        if (!this.battleEnded) {
            this.currentTurnIndex = (this.currentTurnIndex + 1) % this.turnOrder.length;
            this.nextTurn();
        }
    },

    /**
     * Thực thi kỹ năng
     */
    executeSkill(unit, skillKey, target) {
        const skill = unit.data.skills[skillKey];
        const isBasic = skillKey === 'basic';
        const isActive = skillKey === 'active';

        // Lấy bonus sát thương
        let dmgBonus = CharacterManager.getDamageBonus(unit.data);

        // Vegito Bị động 2: bonus EN khi đánh thường
        let enGainBonus = 0;
        if (unit.data.id === 'vegito' && unit.data.level >= GameData.config.unlockLevels.passive2) {
            const passive2 = unit.data.skills.passive2;
            if (passive2.lowHPTrigger && !unit.vegitoShieldTriggered && unit.currentHp / unit.maxHp < passive2.lowHPTrigger.hpThreshold) {
                unit.vegitoShieldTriggered = true;
                const shieldAmount = Math.floor(unit.atk * passive2.lowHPTrigger.shieldAtkMultiplier);
                this.addShield(unit, shieldAmount, 'vegito');
                enGainBonus = passive2.lowHPTrigger.enBonus;
                this.addLog('buff', `${unit.name} kích hoạt Bị Động 2! Nhận khiên ${shieldAmount} và tăng EN nhận được!`);
            }
        }

        // Hồi EN cho đánh thường
        if (isBasic && skill.enGain) {
            unit.currentEn = Math.min(unit.maxEn, unit.currentEn + skill.enGain + enGainBonus);
        }

        // Tiêu EN cho kỹ năng chủ động
        if (isActive && skill.enCost) {
            unit.currentEn = 0;
        }

        // Xác định danh sách mục tiêu
        let targets = [];
        if (skill.type === 'aoe') {
            targets = unit.isPlayer 
                ? this.state.enemyTeam.filter(e => !e.isDead)
                : this.state.playerTeam.filter(p => !p.isDead);
        } else if (skill.type === 'healLowestAlly') {
            const allies = unit.isPlayer 
                ? this.state.playerTeam.filter(p => !p.isDead)
                : this.state.enemyTeam.filter(e => !e.isDead);
            if (allies.length > 0) {
                allies.sort((a, b) => (a.currentHp / a.maxHp) - (b.currentHp / b.maxHp));
                targets = [allies[0]];
            }
        } else if (target) {
            targets = [target];
        } else {
            // Mặc định: mục tiêu 1 của đội địch
            const enemies = unit.isPlayer 
                ? this.state.enemyTeam.filter(e => !e.isDead)
                : this.state.playerTeam.filter(p => !p.isDead);
            if (enemies.length > 0) targets = [enemies[0]];
        }

        // ===== Xử lý hồi máu =====
        if (skill.type === 'healLowestAlly' && targets.length > 0) {
            const healTarget = targets[0];
            let healAmount = Math.floor(unit.atk * skill.healAmount);
            
            // Thần chú 2 Whis: tăng 20% hồi máu
            healAmount = Math.floor(healAmount * (1 + CharacterManager.getHealBonus(unit.data)));
            
            healTarget.currentHp = Math.min(healTarget.maxHp, healTarget.currentHp + healAmount);
            this.addLog('heal', `${unit.name} hồi phục ${healAmount} HP cho ${healTarget.name}!`);
            UI.showDamageNumber(healTarget, healAmount, 'heal');

            // Whis Bị động 1: toàn đội nhận "Bảo Vệ"
            if (unit.data.id === 'whis' && unit.data.level >= GameData.config.unlockLevels.passive1) {
                const passive1 = unit.data.skills.passive1;
                const allies = unit.isPlayer ? this.state.playerTeam : this.state.enemyTeam;
                allies.filter(a => !a.isDead).forEach(ally => {
                    this.addBuff(ally, {
                        type: 'protect',
                        duration: passive1.teamBuff.duration,
                        healPercent: passive1.teamBuff.healPercent,
                        source: unit
                    });
                });
                this.addLog('buff', `Toàn đội nhận "Bảo Vệ" trong ${passive1.teamBuff.duration} lượt!`);
            }

            UI.renderBattleUnits();
            return;
        }

        // ===== Xử lý gây sát thương =====
        targets.forEach(t => {
            if (t.isDead) return;

            // Tính sát thương cơ bản
            let baseDamage = unit.atk * skill.damage;
            
            // Bonus sát thương theo % HP mục tiêu
            if (skill.bonusHpPercent) {
                baseDamage += t.maxHp * skill.bonusHpPercent;
            }

            // Áp dụng bonus sát thương
            baseDamage *= (1 + dmgBonus);

            // Tăng ATK từ buff (Madara)
            const atkBuff = unit.buffs.find(b => b.type === 'atkUp');
            if (atkBuff) {
                baseDamage *= (1 + atkBuff.value);
            }

            // Huyết kích (Madara Bị động 2)
            if (unit.data.id === 'madara' && unit.data.level >= GameData.config.unlockLevels.passive2) {
                const passive2 = unit.data.skills.passive2;
                if (unit.currentHp / unit.maxHp < passive2.hpThreshold) {
                    const hpLostPercent = 1 - (unit.currentHp / unit.maxHp);
                    const bonus = hpLostPercent * passive2.value / 0.01; // mỗi 1% HP mất tăng value
                    baseDamage *= (1 + bonus);
                    if (!unit.buffs.find(b => b.type === 'bloodrage')) {
                        this.addBuff(unit, { type: 'bloodrage', duration: 99 });
                    }
                }
            }

            // Suy giảm (giảm ATK) trên mục tiêu
            const weakenDebuff = t.buffs.find(b => b.type === 'weaken');
            if (weakenDebuff) {
                // Không áp dụng cho người tấn công, mà là khi mục tiêu bị suy giảm
            }

            // Xuyên giáp
            const armorPierce = CharacterManager.getArmorPierce(unit.data);

            // Tính bạo kích
            const { critRate, critMultiplier } = CharacterManager.getCritBonus(unit.data);
            const isCrit = Utils.chance(critRate * 100);
            
            // Áp dụng phòng thủ
            let finalDamage = Utils.applyDefense(baseDamage, t.def, armorPierce);
            
            if (isCrit) {
                finalDamage *= critMultiplier;
            }

            finalDamage = Math.max(1, Math.floor(finalDamage));

            // Gây sát thương
            const actualDamage = this.applyDamage(t, finalDamage, unit);
            UI.showDamageNumber(t, actualDamage, isCrit ? 'crit' : 'damage');
            
            let logMsg = `${unit.name} dùng ${skill.name} gây ${actualDamage} sát thương${isCrit ? ' (BẠO KÍCH!)' : ''} lên ${t.name}`;
            if (skill.bonusHpPercent) {
                logMsg += ` (+${Math.floor(t.maxHp * skill.bonusHpPercent)} từ %HP mục tiêu)`;
            }
            this.addLog(unit.isPlayer ? 'player' : 'enemy', logMsg);

            // ===== Hiệu ứng từ kỹ năng =====

            // Hút máu (Madara kỹ năng chủ động)
            if (skill.lifesteal) {
                const healAmount = Math.floor(actualDamage * skill.lifesteal);
                unit.currentHp = Math.min(unit.maxHp, unit.currentHp + healAmount);
                this.addLog('heal', `${unit.name} hồi phục ${healAmount} HP qua hút máu!`);
                UI.showDamageNumber(unit, healAmount, 'heal');
                
                // Madara Bị động 1: khi hồi phục nhận khiên
                if (unit.data.id === 'madara' && unit.data.level >= GameData.config.unlockLevels.passive1) {
                    const shieldAmount = Math.floor(unit.maxHp * unit.data.skills.passive1.value);
                    this.addShield(unit, shieldAmount, 'madara');
                    this.addLog('buff', `${unit.name} nhận khiên ${shieldAmount} từ Bị Động 1!`);
                }
            }

            // Tự tạo khiên (Omega Shenron kỹ năng chủ động)
            if (skill.selfShieldPercent) {
                const shieldAmount = Math.floor(actualDamage * skill.selfShieldPercent);
                this.addShield(unit, shieldAmount, 'omega');
                this.addLog('buff', `${unit.name} tạo khiên ${shieldAmount}!`);
            }

            // Buff ATK bản thân (Madara)
            if (skill.selfBuff) {
                this.addBuff(unit, {
                    type: 'atkUp',
                    value: skill.selfBuff.value,
                    duration: skill.selfBuff.duration
                });
                this.addLog('buff', `${unit.name} tăng ${skill.selfBuff.value * 100}% ATK trong ${skill.selfBuff.duration} hiệp!`);
            }

            // Rực lửa (Nhà Lữ Hành Bị động 2)
            if (isBasic && unit.data.id === 'nha_ly_hanh' && unit.data.level >= GameData.config.unlockLevels.passive2) {
                const passive2 = unit.data.skills.passive2;
                this.addStackEffect(t, {
                    type: 'burning',
                    stacks: passive2.stacks,
                    maxStacks: passive2.maxStacks,
                    damagePerStack: passive2.damagePerStack,
                    duration: passive2.duration
                });
                this.addLog('debuff', `${t.name} nhận "Rực Lửa"!`);
            }

            // Chảy máu+ (Vegito Bị động 1 - đánh thường)
            if (isBasic && unit.data.id === 'vegito' && unit.data.level >= GameData.config.unlockLevels.passive1) {
                const passive1 = unit.data.skills.passive1;
                this.addEffect(t, {
                    type: 'bleeding2',
                    damagePercent: passive1.damage,
                    duration: passive1.duration,
                    source: unit
                });
                this.addLog('debuff', `${t.name} nhận "Chảy Máu+"!`);
            }

            // Suy giảm (Whis đánh thường)
            if (isBasic && unit.data.id === 'whis' && unit.data.level >= GameData.config.unlockLevels.passive2) {
                const passive2 = unit.data.skills.passive2;
                if (Utils.chance(passive2.chance * 100)) {
                    this.addBuff(t, {
                        type: 'weaken',
                        duration: passive2.duration,
                        atkReduction: passive2.atkReduction
                    });
                    this.addLog('debuff', `${t.name} bị "Suy Giảm"!`);
                }
            }
            // Suy giảm từ skill basic của Whis (có thể có 2 lần định nghĩa)
            if (isBasic && skill.applyWeaken) {
                if (Utils.chance(skill.applyWeaken.chance * 100)) {
                    this.addBuff(t, {
                        type: 'weaken',
                        duration: skill.applyWeaken.duration,
                        atkReduction: skill.applyWeaken.atkReduction
                    });
                    this.addLog('debuff', `${t.name} bị "Suy Giảm"!`);
                }
            }

            // Thiên Mệnh (Omega Shenron Bị động 2)
            if (unit.data.id === 'omega_shenron' && unit.data.level >= GameData.config.unlockLevels.passive2) {
                const passive2 = unit.data.skills.passive2;
                this.addStackEffect(t, {
                    type: 'destiny',
                    stacks: 1,
                    maxStacks: passive2.stacksNeeded,
                    duration: 99
                });
                
                // Kiểm tra đủ 3 tầng
                const destinyEffect = t.effects.find(e => e.type === 'destiny');
                if (destinyEffect && destinyEffect.stacks >= passive2.stacksNeeded) {
                    const drainAmount = Math.floor(t.currentHp * passive2.drainPercent);
                    t.currentHp = Math.max(1, t.currentHp - drainAmount);
                    unit.currentHp = Math.min(unit.maxHp, unit.currentHp + drainAmount);
                    destinyEffect.stacks = 0;
                    this.addLog('buff', `${unit.name} kích hoạt "Thiên Mệnh"! Cướp ${drainAmount} HP từ ${t.name}!`);
                    UI.showDamageNumber(t, drainAmount, 'damage');
                    UI.showDamageNumber(unit, drainAmount, 'heal');
                }
            }

            // Kỹ năng chủ động Vegito: Chảy máu + Chảy máu+
            if (isActive && skill.applyBleeding) {
                this.addStackEffect(t, {
                    type: 'bleeding',
                    stacks: skill.applyBleeding.stacks,
                    maxStacks: skill.applyBleeding.maxStacks,
                    damagePerStack: skill.applyBleeding.damagePerStack,
                    duration: 99
                });
                this.addLog('debuff', `${t.name} nhận ${skill.applyBleeding.stacks} tầng "Chảy Máu"!`);
            }
            if (isActive && skill.applyBleeding2) {
                this.addEffect(t, {
                    type: 'bleeding2',
                    damagePercent: skill.applyBleeding2.damage,
                    duration: skill.applyBleeding2.duration,
                    source: unit
                });
                this.addLog('debuff', `${t.name} nhận "Chảy Máu+"!`);
            }

            // Kiểm tra chết
            if (t.currentHp <= 0) {
                t.isDead = true;
                this.addLog('system', `${t.name} đã ngã xuống!`);
            }
        });

        UI.renderBattleUnits();
    },

    /**
     * Áp dụng sát thương (xử lý khiên trước)
     */
    applyDamage(target, damage, source, isDot = false) {
        let remainingDamage = damage;

        // Hấp thụ khiên
        const shieldEffect = target.effects.find(e => e.type === 'shield');
        if (shieldEffect && shieldEffect.value > 0) {
            if (shieldEffect.value >= remainingDamage) {
                shieldEffect.value -= remainingDamage;
                UI.showDamageNumber(target, remainingDamage, 'shield');
                return 0;
            } else {
                remainingDamage -= shieldEffect.value;
                shieldEffect.value = 0;
                target.effects = target.effects.filter(e => e !== shieldEffect);
            }
        }

        // Buff "Bảo Vệ" (Whis) - hồi máu khi nhận sát thương
        if (!isDot) {
            const protectBuff = target.buffs.find(b => b.type === 'protect');
            if (protectBuff && protectBuff.source) {
                let healAmount = Math.floor(protectBuff.source.atk * protectBuff.healPercent);
                healAmount = Math.floor(healAmount * (1 + CharacterManager.getHealBonus(protectBuff.source.data)));
                target.currentHp = Math.min(target.maxHp, target.currentHp + healAmount);
                this.addLog('heal', `${target.name} hồi phục ${healAmount} HP từ "Bảo Vệ"!`);
            }
        }

        target.currentHp = Math.max(0, target.currentHp - remainingDamage);
        return remainingDamage;
    },

    /**
     * Thêm hiệu ứng dạng tầng
     */
    addStackEffect(target, effectData) {
        let existing = target.effects.find(e => e.type === effectData.type);
        if (existing) {
            existing.stacks = Math.min(effectData.maxStacks, existing.stacks + effectData.stacks);
            if (effectData.duration !== undefined) existing.duration = effectData.duration;
        } else {
            target.effects.push({ ...effectData });
        }
    },

    /**
     * Thêm hiệu ứng thông thường
     */
    addEffect(target, effectData) {
        // Loại bỏ hiệu ứng cùng loại cũ
        target.effects = target.effects.filter(e => e.type !== effectData.type);
        target.effects.push({ ...effectData });
    },

    /**
     * Thêm khiên
     */
    addShield(unit, value, source) {
        let existing = unit.effects.find(e => e.type === 'shield');
        if (existing) {
            existing.value += value;
        } else {
            unit.effects.push({ type: 'shield', value, duration: 99, source });
        }
    },

    /**
     * Thêm buff
     */
    addBuff(unit, buffData) {
        // Loại bỏ buff cùng loại cũ
        unit.buffs = unit.buffs.filter(b => b.type !== buffData.type);
        unit.buffs.push({ ...buffData });
    },

    /**
     * Kiểm tra kết thúc trận
     */
    checkBattleEnd() {
        const playerAlive = this.state.playerTeam.some(u => !u.isDead);
        const enemyAlive = this.state.enemyTeam.some(u => !u.isDead);

        if (!playerAlive) {
            this.battleEnded = true;
            this.endBattle(false);
            return true;
        }

        if (!enemyAlive) {
            this.battleEnded = true;
            this.endBattle(true);
            return true;
        }

        return false;
    },

    /**
     * Kết thúc trận đấu
     */
    endBattle(victory) {
        document.getElementById('skillButtons').innerHTML = '<p class="text-muted">Trận đấu kết thúc</p>';
        
        setTimeout(() => {
            UI.showBattleResult(victory, this.state);
        }, 800);
    },

    /**
     * Thêm log trận đấu
     */
    addLog(type, message) {
        this.state.log.push({ type, message, turn: this.state.turn });
        UI.addBattleLogEntry(type, message);
    }
};
