/**
 * data.js - Dữ liệu game: nhân vật, giftcode, cấu hình
 */

const GameData = {
    // Cấu hình chung
    config: {
        maxPlayerLevel: 150,
        maxCharLevel: 220,
        baseCritRate: 0.18,
        baseCritMultiplier: 3,
        unlockLevels: {
            passive1: 40,
            passive2: 80,
            divine1: 150,
            divine2: 220
        }
    },

    // Giftcode
    giftcodes: {
        'TANTHU001': { starLight: 500, used: false, desc: '500 Ánh Sao' },
        'TANTHU002': { starLight: 500, used: false, desc: '500 Ánh Sao' },
        'TANTHU003': { starLight: 500, used: false, desc: '500 Ánh Sao' },
        'TFJIKOKDAB': { diamond: 299, used: false, desc: '299 Kim Cương' },
        'TRUNGTHUVV': { starLight: 4000, used: false, desc: '4000 Ánh Sao' },
        'TRUNGTHU2026': { starLight: 4000, used: false, desc: '4000 Ánh Sao' }
    },

    // Dữ liệu nhân vật cơ sở
    characters: {
        'nha_ly_hanh': {
            id: 'nha_ly_hanh',
            name: 'Nhà Lữ Hành',
            type: 'ATK',
            icon: 'ri-user-3-fill',
            baseStats: {
                hp: 280,
                atk: 13,
                def: 38,
                spd: 139,
                en: 5
            },
            hasDivine: false,
            skills: {
                basic: {
                    name: 'Đánh Thường',
                    enGain: 1,
                    desc: 'Gây 94% ATK lên 1 mục tiêu, hồi 1 EN',
                    type: 'single',
                    damage: 0.94,
                    effects: []
                },
                active: {
                    name: 'Kỹ Năng Chủ Động',
                    enCost: 5,
                    desc: 'Gây 220% ATK kèm 3% HP tối đa của mục tiêu lên 1 mục tiêu',
                    type: 'single',
                    damage: 2.2,
                    bonusHpPercent: 0.03,
                    effects: []
                },
                passive1: {
                    name: 'Bị Động 1',
                    unlockLevel: 40,
                    desc: 'Mỗi 2 hiệp, Nhà Lữ Hành được nhận 2 EN',
                    trigger: 'turnInterval',
                    interval: 2,
                    effect: 'gainEN',
                    value: 2
                },
                passive2: {
                    name: 'Bị Động 2',
                    unlockLevel: 80,
                    desc: 'Đánh thường gây "Rực Lửa" tầng thứ 2. "Rực Lửa": đốt 1% HP tối đa của mục tiêu, tối đa 5 tầng. Mỗi tầng cộng dồn, tăng 1% đốt',
                    trigger: 'basicAttack',
                    effect: 'burning',
                    stacks: 2,
                    maxStacks: 5,
                    damagePerStack: 0.01,
                    duration: 99
                }
            }
        },

        'madara': {
            id: 'madara',
            name: 'Madara (Lục Đạo)',
            type: 'ATK',
            icon: 'ri-fire-fill',
            baseStats: {
                hp: 235,
                atk: 17.9,
                def: 30,
                spd: 150,
                en: 5
            },
            hasDivine: true,
            skills: {
                basic: {
                    name: 'Đánh Thường',
                    enGain: 1.3,
                    desc: 'Hồi 1.3 EN. Gây 98% ATK lên 1 mục tiêu kèm 2% HP tối đa của mục tiêu',
                    type: 'single',
                    damage: 0.98,
                    bonusHpPercent: 0.02,
                    effects: []
                },
                active: {
                    name: 'Kỹ Năng Chủ Động',
                    enCost: 5,
                    desc: 'Gây ST bằng 200% ATK lên toàn bộ mục tiêu kèm 5% HP tối đa của mục tiêu đó. Hồi phục bản thân bằng 20% ST gây ra. Đồng thời tăng 5% ST gây ra của bản thân trong 3 hiệp tiếp theo',
                    type: 'aoe',
                    damage: 2.0,
                    bonusHpPercent: 0.05,
                    lifesteal: 0.2,
                    selfBuff: {
                        effect: 'atkUp',
                        value: 0.05,
                        duration: 3
                    }
                },
                passive1: {
                    name: 'Bị Động 1',
                    unlockLevel: 40,
                    desc: 'Khi nhận được "hồi phục" từ bất cứ đâu. Madara nhận lớp khiên bằng 8% HP tối đa bản thân',
                    trigger: 'onHeal',
                    effect: 'shield',
                    value: 0.08
                },
                passive2: {
                    name: 'Bị Động 2',
                    unlockLevel: 80,
                    desc: 'Khi HP dưới 30%. Madara nhận "Huyết Kích": mỗi 1% HP mất đi tăng 2% ST gây ra',
                    trigger: 'lowHP',
                    hpThreshold: 0.3,
                    effect: 'bloodrage',
                    value: 0.02
                },
                divine1: {
                    name: 'Thần Chú 1',
                    unlockLevel: 150,
                    desc: 'Tăng 8% ATK; 10% DEF',
                    statBonus: {
                        atk: 0.08,
                        def: 0.10
                    }
                },
                divine2: {
                    name: 'Thần Chú 2',
                    unlockLevel: 220,
                    desc: 'Tăng 15% tỉ lệ bạo kích; ST bạo kích tăng 50%',
                    critBonus: 0.15,
                    critDmgBonus: 0.5
                }
            }
        },

        'omega_shenron': {
            id: 'omega_shenron',
            name: 'Omega Shenron',
            type: 'DEF',
            icon: 'ri-shield-star-fill',
            baseStats: {
                hp: 325,
                atk: 11,
                def: 52,
                spd: 152,
                en: 4
            },
            hasDivine: true,
            skills: {
                basic: {
                    name: 'Đánh Thường',
                    enGain: 0.9,
                    desc: 'Gây 78% ATK lên 1 mục tiêu, hồi 0.9 EN',
                    type: 'single',
                    damage: 0.78,
                    effects: []
                },
                active: {
                    name: 'Kỹ Năng Chủ Động',
                    enCost: 4,
                    desc: 'Gây 300% ATK lên 1 mục tiêu có HP thấp nhất. Bản thân nhận 1 lớp khiên bằng 20% ST gây ra',
                    type: 'lowestHP',
                    damage: 3.0,
                    selfShieldPercent: 0.2
                },
                passive1: {
                    name: 'Bị Động 1',
                    unlockLevel: 40,
                    desc: 'Hiệp đầu tiên của trận. Bản thân nhận 1 lớp khiên bằng 100% HP bản thân',
                    trigger: 'battleStart',
                    effect: 'shield',
                    value: 1.0
                },
                passive2: {
                    name: 'Bị Động 2',
                    unlockLevel: 80,
                    desc: 'Mỗi lần gây ST, đánh dấu lên mục tiêu đó 1 tầng "Thiên Mệnh". "Thiên Mệnh": khi đủ 3 tầng, reset tầng và cướp đi 3% HP hiện tại của mục tiêu cho bản thân',
                    trigger: 'onDamage',
                    effect: 'destiny',
                    stacksNeeded: 3,
                    drainPercent: 0.03
                },
                divine1: {
                    name: 'Thần Chú 1',
                    unlockLevel: 150,
                    desc: '+20% DEF; +5% HP tối đa',
                    statBonus: {
                        def: 0.20,
                        hp: 0.05
                    }
                },
                divine2: {
                    name: 'Thần Chú 2',
                    unlockLevel: 220,
                    desc: 'Xuyên giáp +10% (bỏ qua 10% DEF mục tiêu)',
                    armorPierce: 0.10
                }
            }
        },

        'vegito': {
            id: 'vegito',
            name: 'Vegito',
            type: 'SKL',
            icon: 'ri-flashlight-fill',
            baseStats: {
                hp: 278,
                atk: 15,
                def: 45,
                spd: 170,
                en: 3
            },
            hasDivine: true,
            skills: {
                basic: {
                    name: 'Đánh Thường',
                    enGain: 0.9,
                    desc: 'Gây 98% ATK lên 1 mục tiêu, hồi 0.9 EN',
                    type: 'single',
                    damage: 0.98,
                    effects: []
                },
                active: {
                    name: 'Kỹ Năng Chủ Động',
                    enCost: 3,
                    desc: 'Gây ST bằng 75% ATK lên tất cả mục tiêu, và kích hoạt 3 tầng hiệu ứng [Chảy Máu] lên chúng. Sau đó áp dụng thêm hiệu ứng [Chảy Máu+] của riêng Vegito (không bị chèn ép bởi hiệu ứng [Chảy Máu] thông thường). [Chảy Máu+] mỗi hiệp gây ST bằng 40% ATK, kéo dài 3 hiệp',
                    type: 'aoe',
                    damage: 0.75,
                    applyBleeding: { stacks: 3, maxStacks: 5, damagePerStack: 0.01 },
                    applyBleeding2: { damage: 0.4, duration: 3 }
                },
                passive1: {
                    name: 'Bị Động 1',
                    unlockLevel: 40,
                    desc: 'Đòn đánh thường áp dụng [Chảy Máu+]',
                    trigger: 'basicAttack',
                    effect: 'bleeding2',
                    damage: 0.4,
                    duration: 3
                },
                passive2: {
                    name: 'Bị Động 2',
                    unlockLevel: 80,
                    desc: 'Tăng ST thêm 30%. Khi HP dưới 50%, nhận được [Khiên] bằng 275% ATK bản thân, đồng thời tăng thêm 0.5 năng lượng nhận được từ đánh thường (Chỉ kích hoạt 1 lần trên 1 trận chiến)',
                    damageBonus: 0.3,
                    lowHPTrigger: {
                        hpThreshold: 0.5,
                        shieldAtkMultiplier: 2.75,
                        enBonus: 0.5,
                        oncePerBattle: true
                    }
                },
                divine1: {
                    name: 'Thần Chú 1',
                    unlockLevel: 150,
                    desc: 'Tăng 10% ST của [Chảy Máu+]',
                    bleeding2Bonus: 0.10
                },
                divine2: {
                    name: 'Thần Chú 2',
                    unlockLevel: 220,
                    desc: 'ATK tăng 25%; HP tăng 14%',
                    statBonus: {
                        atk: 0.25,
                        hp: 0.14
                    }
                }
            }
        },

        'whis': {
            id: 'whis',
            name: 'Whis',
            type: 'SKL',
            icon: 'ri-heart-pulse-fill',
            baseStats: {
                hp: 282,
                atk: 14,
                def: 47,
                spd: 173,
                en: 4
            },
            hasDivine: true,
            skills: {
                basic: {
                    name: 'Đánh Thường',
                    enGain: 1.1,
                    desc: 'Gây 88% ATK lên 1 mục tiêu, hồi 1.1 EN. Có 24% cơ hội mục tiêu bị "Suy Giảm" (giảm 20% ATK)',
                    type: 'single',
                    damage: 0.88,
                    applyWeaken: { chance: 0.24, duration: 2, atkReduction: 0.2 }
                },
                active: {
                    name: 'Kỹ Năng Chủ Động',
                    enCost: 4,
                    desc: 'Hồi HP bằng 150% ATK bản thân cho 1 mục tiêu đồng minh có HP thấp nhất',
                    type: 'healLowestAlly',
                    healAmount: 1.5
                },
                passive1: {
                    name: 'Bị Động 1',
                    unlockLevel: 40,
                    desc: 'Khi sử dụng kỹ năng chủ động, cung cấp cho toàn đội "Bảo Vệ" trong 2 lượt. "Bảo Vệ": khi nhận ST, bản thân hồi phục bằng 45% ATK của Whis',
                    trigger: 'onActiveSkill',
                    teamBuff: {
                        effect: 'protect',
                        duration: 2,
                        healPercent: 0.45
                    }
                },
                passive2: {
                    name: 'Bị Động 2',
                    unlockLevel: 80,
                    desc: 'Khi đánh thường, có 24% cơ hội mục tiêu bị "Suy Giảm". "Suy Giảm": giảm 20% ATK của mục tiêu',
                    trigger: 'basicAttack',
                    effect: 'weaken',
                    chance: 0.24,
                    duration: 2,
                    atkReduction: 0.2
                },
                divine1: {
                    name: 'Thần Chú 1',
                    unlockLevel: 150,
                    desc: '+20% ATK; +12% HP',
                    statBonus: {
                        atk: 0.20,
                        hp: 0.12
                    }
                },
                divine2: {
                    name: 'Thần Chú 2',
                    unlockLevel: 220,
                    desc: 'Tăng 20% khả năng hồi phục',
                    healBonus: 0.20
                }
            }
        }
    },

    // Dữ liệu chương & ải
    chapters: [
        {
            id: 1,
            name: 'Chương 1: Khởi Đầu',
            levels: 10,
            desc: 'Những thử thách đầu tiên'
        },
        {
            id: 2,
            name: 'Chương 2: Hiểm Trở',
            levels: 10,
            desc: 'Đối thủ mạnh hơn đáng kể'
        },
        {
            id: 3,
            name: 'Chương 3: Tối Thượng',
            levels: 10,
            desc: 'Thử thách cuối cùng'
        }
    ],

    // Phần thưởng cơ bản mỗi ải
    baseRewards: {
        starLight: 10,
        diamond: 50,
        vpnc: 100
    }
};

/**
 * Tạo dữ liệu bot đơn giản theo loại
 */
function createBotData(botType, powerMultiplier) {
    const templates = {
        ATK: {
            name: 'Kỵ Sĩ Tấn Công',
            type: 'ATK',
            icon: 'ri-sword-line',
            baseStats: { hp: 200, atk: 14, def: 25, spd: 130, en: 4 },
            skills: {
                basic: { name: 'Đánh Thường', enGain: 1, type: 'single', damage: 0.9 },
                active: { name: 'Kỹ Năng', enCost: 4, type: 'single', damage: 1.8 }
            }
        },
        DEF: {
            name: 'Vệ Binh Phòng Thủ',
            type: 'DEF',
            icon: 'ri-shield-line',
            baseStats: { hp: 280, atk: 9, def: 45, spd: 120, en: 3 },
            skills: {
                basic: { name: 'Đánh Thường', enGain: 0.8, type: 'single', damage: 0.75 },
                active: { name: 'Kỹ Năng', enCost: 3, type: 'single', damage: 2.0 }
            }
        },
        SKL: {
            name: 'Pháp Sư Kỹ Năng',
            type: 'SKL',
            icon: 'ri-magic-line',
            baseStats: { hp: 220, atk: 12, def: 30, spd: 140, en: 4 },
            skills: {
                basic: { name: 'Đánh Thường', enGain: 1, type: 'single', damage: 0.85 },
                active: { name: 'Kỹ Năng', enCost: 4, type: 'aoe', damage: 1.2 }
            }
        }
    };

    const template = templates[botType];
    const bot = Utils.deepClone(template);
    
    // Áp dụng hệ số sức mạnh
    bot.baseStats.hp = Math.floor(bot.baseStats.hp * powerMultiplier);
    bot.baseStats.atk = Utils.round(bot.baseStats.atk * powerMultiplier, 1);
    bot.baseStats.def = Math.floor(bot.baseStats.def * powerMultiplier);
    
    bot.id = 'bot_' + botType + '_' + Utils.generateId();
    bot.isBot = true;
    
    return bot;
}
