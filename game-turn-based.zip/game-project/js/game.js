/**
 * game.js - Core game logic: quản lý trạng thái, lưu dữ liệu, khởi tạo
 */

const Game = {
    // Trạng thái game
    state: {
        player: null,
        characters: {}, // id -> character instance
        giftcodes: {}, // lưu trạng thái giftcode đã dùng
        progress: {
            maxChapterCleared: 0, // index-based
            maxLevelCleared: -1 // index-based trong chapter hiện tại
        },
        currentScreen: 'start',
        selectedTeam: [],
        currentBattle: null
    },

    // Storage key
    STORAGE_KEY: 'turn_based_game_save_v1',

    /**
     * Khởi tạo game
     */
    init() {
        this.load();
        if (!this.state.player) {
            this.createNewGame();
        }
        this.migrateGiftcodes();
        UI.init();
    },

    /**
     * Tạo dữ liệu game mới
     */
    createNewGame() {
        this.state.player = {
            level: 1,
            exp: 0,
            name: 'Nhà Lữ Hành',
            resources: {
                starLight: 0,
                diamond: 0,
                vpnc: 0,
                gold: 1000 // Vàng khởi đầu
            }
        };

        // Tạo nhân vật mặc định: Nhà Lữ Hành
        this.addCharacter('nha_ly_hanh');

        this.state.giftcodes = {};
        this.state.progress = {
            maxChapterCleared: 0,
            maxLevelCleared: -1
        };

        this.save();
    },

    /**
     * Thêm nhân vật vào danh sách của người chơi
     */
    addCharacter(charId) {
        const baseData = GameData.characters[charId];
        if (!baseData) return null;

        const charInstance = {
            ...Utils.deepClone(baseData),
            instanceId: charId + '_' + Utils.generateId(),
            level: 1,
            exp: 0,
            currentStats: this.calculateStats(baseData.baseStats, 1, baseData)
        };

        this.state.characters[charInstance.instanceId] = charInstance;
        return charInstance;
    },

    /**
     * Tính chỉ số thực tế dựa trên level và thần chú
     */
    calculateStats(baseStats, level, charData) {
        const stats = { ...baseStats };
        
        // Tăng chỉ số theo level (mỗi level tăng khoảng 1.5%)
        const levelMultiplier = 1 + (level - 1) * 0.015;
        stats.hp = Math.floor(stats.hp * levelMultiplier);
        stats.atk = Utils.round(stats.atk * levelMultiplier, 1);
        stats.def = Math.floor(stats.def * levelMultiplier);
        stats.spd = Math.floor(stats.spd * (1 + (level - 1) * 0.005));
        // EN không tăng theo level

        // Áp dụng thần chú nếu có
        if (charData.hasDivine) {
            const skills = charData.skills;
            if (level >= GameData.config.unlockLevels.divine1 && skills.divine1 && skills.divine1.statBonus) {
                if (skills.divine1.statBonus.hp) stats.hp = Math.floor(stats.hp * (1 + skills.divine1.statBonus.hp));
                if (skills.divine1.statBonus.atk) stats.atk = Utils.round(stats.atk * (1 + skills.divine1.statBonus.atk), 1);
                if (skills.divine1.statBonus.def) stats.def = Math.floor(stats.def * (1 + skills.divine1.statBonus.def));
            }
            if (level >= GameData.config.unlockLevels.divine2 && skills.divine2 && skills.divine2.statBonus) {
                if (skills.divine2.statBonus.hp) stats.hp = Math.floor(stats.hp * (1 + skills.divine2.statBonus.hp));
                if (skills.divine2.statBonus.atk) stats.atk = Utils.round(stats.atk * (1 + skills.divine2.statBonus.atk), 1);
                if (skills.divine2.statBonus.def) stats.def = Math.floor(stats.def * (1 + skills.divine2.statBonus.def));
            }
        }

        return stats;
    },

    /**
     * Lưu dữ liệu vào localStorage
     */
    save() {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.state));
        } catch (e) {
            console.error('Lỗi lưu dữ liệu:', e);
        }
    },

    /**
     * Tải dữ liệu từ localStorage
     */
    load() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            if (data) {
                this.state = JSON.parse(data);
                return true;
            }
        } catch (e) {
            console.error('Lỗi tải dữ liệu:', e);
        }
        return false;
    },

    /**
     * Đặt lại toàn bộ dữ liệu
     */
    reset() {
        localStorage.removeItem(this.STORAGE_KEY);
        this.state = {
            player: null,
            characters: {},
            giftcodes: {},
            progress: { maxChapterCleared: 0, maxLevelCleared: -1 },
            currentScreen: 'start',
            selectedTeam: [],
            currentBattle: null
        };
        this.createNewGame();
    },

    /**
     * Migrate giftcodes từ dữ liệu cũ
     */
    migrateGiftcodes() {
        if (!this.state.giftcodes) {
            this.state.giftcodes = {};
        }
    },

    /**
     * Kiểm tra và đổi giftcode
     */
    redeemGiftcode(code) {
        code = code.toUpperCase().trim();
        const giftData = GameData.giftcodes[code];
        
        if (!giftData) {
            return { success: false, message: 'Giftcode không hợp lệ!' };
        }
        
        if (this.state.giftcodes[code]) {
            return { success: false, message: 'Giftcode đã được sử dụng!' };
        }

        // Áp dụng phần thưởng
        if (giftData.starLight) this.state.player.resources.starLight += giftData.starLight;
        if (giftData.diamond) this.state.player.resources.diamond += giftData.diamond;
        if (giftData.vpnc) this.state.player.resources.vpnc += giftData.vpnc;
        if (giftData.gold) this.state.player.resources.gold += giftData.gold;

        this.state.giftcodes[code] = true;
        this.save();

        return { 
            success: true, 
            message: `Đổi thành công! Nhận được: ${giftData.desc}` 
        };
    },

    /**
     * Thêm kinh nghiệm cho người chơi
     */
    addPlayerExp(exp) {
        this.state.player.exp += exp;
        let leveledUp = false;
        
        while (this.state.player.level < GameData.config.maxPlayerLevel) {
            const expNeeded = Utils.getExpForLevel(this.state.player.level + 1);
            if (this.state.player.exp >= expNeeded) {
                this.state.player.exp -= expNeeded;
                this.state.player.level++;
                leveledUp = true;
            } else {
                break;
            }
        }
        
        this.save();
        return leveledUp;
    },

    /**
     * Lấy phần thưởng dựa trên level người chơi
     */
    getRewards() {
        const playerLevel = this.state.player.level;
        return {
            starLight: Utils.getRewardByLevel(GameData.baseRewards.starLight, playerLevel),
            diamond: Utils.getRewardByLevel(GameData.baseRewards.diamond, playerLevel),
            vpnc: Utils.getRewardByLevel(GameData.baseRewards.vpnc, playerLevel)
        };
    },

    /**
     * Cập nhật tiến độ ải
     */
    updateProgress(chapterIndex, levelIndex) {
        const currentTotal = this.state.progress.maxChapterCleared * 10 + this.state.progress.maxLevelCleared;
        const newTotal = chapterIndex * 10 + levelIndex;
        
        if (newTotal > currentTotal) {
            this.state.progress.maxChapterCleared = chapterIndex;
            this.state.progress.maxLevelCleared = levelIndex;
            this.save();
        }
    },

    /**
     * Kiểm tra xem ải có mở khóa không
     */
    isLevelUnlocked(chapterIndex, levelIndex) {
        if (chapterIndex === 0 && levelIndex === 0) return true;
        
        const currentTotal = this.state.progress.maxChapterCleared * 10 + this.state.progress.maxLevelCleared;
        const targetTotal = chapterIndex * 10 + levelIndex;
        
        return targetTotal <= currentTotal + 1;
    },

    /**
     * Kiểm tra xem ải đã hoàn thành chưa
     */
    isLevelCleared(chapterIndex, levelIndex) {
        const currentTotal = this.state.progress.maxChapterCleared * 10 + this.state.progress.maxLevelCleared;
        const targetTotal = chapterIndex * 10 + levelIndex;
        
        return targetTotal <= currentTotal;
    },

    /**
     * Chuyển màn hình
     */
    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const screen = document.getElementById(screenId);
        if (screen) screen.classList.add('active');
        this.state.currentScreen = screenId;
    }
};

// Khởi tạo game khi trang tải xong
document.addEventListener('DOMContentLoaded', () => {
    Game.init();
});
