/**
 * utils.js - Các hàm tiện ích chung
 */

const Utils = {
    /**
     * Tạo số ngẫu nhiên trong khoảng [min, max]
     */
    random(min, max) {
        return Math.random() * (max - min) + min;
    },

    /**
     * Tạo số nguyên ngẫu nhiên trong khoảng [min, max]
     */
    randomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },

    /**
     * Kiểm tra xác suất
     * @param {number} percent - Tỷ lệ phần trăm (0-100)
     */
    chance(percent) {
        return Math.random() * 100 < percent;
    },

    /**
     * Làm tròn số đến số chữ số thập phân
     */
    round(num, decimals = 2) {
        const factor = Math.pow(10, decimals);
        return Math.round(num * factor) / factor;
    },

    /**
     * Giới hạn giá trị trong khoảng [min, max]
     */
    clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    },

    /**
     * Tính toán sát thương sau khi trừ phòng thủ
     * Mỗi 5 DEF giảm 0.5% sát thương
     */
    applyDefense(damage, def, armorPierce = 0) {
        const effectiveDef = def * (1 - armorPierce);
        const reduction = (effectiveDef * 0.5 / 5) / 100;
        return Math.max(1, damage * (1 - reduction));
    },

    /**
     * Tính toán kinh nghiệm cần để lên level
     * Level 1->2: 100 exp, tăng 22% theo level
     */
    getExpForLevel(level) {
        if (level <= 1) return 0;
        let exp = 100;
        for (let i = 2; i < level; i++) {
            exp *= 1.22;
        }
        return Math.floor(exp);
    },

    /**
     * Tính exp nhận được từ ải
     * Ải 1: 500 exp, tăng 25% theo ải
     */
    getExpFromStage(stageIndex) {
        return Math.floor(500 * Math.pow(1.25, stageIndex));
    },

    /**
     * Tính phần thưởng vật phẩm theo level người chơi
     * Tăng 20% mỗi 5 level người chơi
     */
    getRewardByLevel(baseValue, playerLevel) {
        const multiplier = Math.pow(1.2, Math.floor(playerLevel / 5));
        return Math.floor(baseValue * multiplier);
    },

    /**
     * Tính chi phí nâng cấp nhân vật
     * Tăng 5% so với level trước đó
     */
    getUpgradeCost(currentLevel) {
        const baseVpnc = 100;
        const baseGold = 800;
        const multiplier = Math.pow(1.05, currentLevel - 1);
        return {
            vpnc: Math.ceil(baseVpnc * multiplier),
            gold: Math.ceil(baseGold * multiplier)
        };
    },

    /**
     * Tính chỉ số sức mạnh bot
     * @param {number} chapterIndex - Chỉ số chương (0-based)
     * @param {number} levelIndex - Chỉ số ải trong chương (0-based)
     * Yếu hơn 30% so với tướng chuẩn, +15%/ải, +40%/chương
     */
    getBotPowerMultiplier(chapterIndex, levelIndex) {
        const baseMultiplier = 0.7; // Yếu hơn 30%
        const levelIncrease = Math.pow(1.15, levelIndex);
        const chapterIncrease = Math.pow(1.4, chapterIndex);
        return baseMultiplier * levelIncrease * chapterIncrease;
    },

    /**
     * Định dạng số lớn (ví dụ: 1000 -> 1.000)
     */
    formatNumber(num) {
        return Math.floor(num).toLocaleString('vi-VN');
    },

    /**
     * Tạo ID ngẫu nhiên
     */
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    /**
     * Sao chép sâu đối tượng
     */
    deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    },

    /**
     * Trì hoãn thực thi (Promise)
     */
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    /**
     * Lấy tên loại nhân vật
     */
    getTypeName(type) {
        const names = { ATK: 'Tấn Công', DEF: 'Phòng Thủ', SKL: 'Kỹ Năng' };
        return names[type] || type;
    },

    /**
     * Lấy tên hiệu ứng
     */
    getEffectName(effect) {
        const names = {
            burning: 'Rực Lửa',
            bleeding: 'Chảy Máu',
            bleeding2: 'Chảy Máu+',
            shield: 'Khiên',
            bloodrage: 'Huyết Kích',
            destiny: 'Thiên Mệnh',
            protect: 'Bảo Vệ',
            weaken: 'Suy Giảm',
            stun: 'Đông Kết',
            atkUp: 'Tăng ATK'
        };
        return names[effect] || effect;
    }
};
