/**
 * stage.js - Quản lý đấu ải, chương, tạo bot
 */

const StageManager = {
    currentChapter: 0,
    currentLevel: 0,

    /**
     * Render danh sách chương
     */
    renderChapters() {
        const container = document.getElementById('chaptersContainer');
        if (!container) return;

        container.innerHTML = '';

        GameData.chapters.forEach((chapter, idx) => {
            const isUnlocked = idx <= Game.state.progress.maxChapterCleared;
            const isCompleted = idx < Game.state.progress.maxChapterCleared;
            
            const levelsCleared = idx < Game.state.progress.maxChapterCleared 
                ? chapter.levels 
                : Math.max(0, Game.state.progress.maxLevelCleared + 1);

            const card = document.createElement('div');
            card.className = `chapter-card ${!isUnlocked ? 'locked' : ''} ${isCompleted ? 'completed' : ''}`;
            
            card.innerHTML = `
                <div class="chapter-number">CHƯƠNG ${idx + 1}</div>
                <div class="chapter-name">${chapter.name}</div>
                <div class="chapter-info">${chapter.desc}</div>
                <div class="chapter-status">
                    <span>Ải: ${levelsCleared}/${chapter.levels}</span>
                    <span class="${isCompleted ? 'status-cleared' : isUnlocked ? 'status-current' : 'status-locked'}">
                        ${isCompleted ? 'Hoàn Thành' : isUnlocked ? 'Đang Tiến Hành' : 'Đang Khoá'}
                    </span>
                </div>
            `;

            if (isUnlocked) {
                card.addEventListener('click', () => {
                    this.currentChapter = idx;
                    this.renderLevels();
                    document.getElementById('chapterTitle').textContent = chapter.name;
                    Game.showScreen('stageLevelsScreen');
                });
            }

            container.appendChild(card);
        });
    },

    /**
     * Render danh sách ải trong chương
     */
    renderLevels() {
        const container = document.getElementById('levelsContainer');
        if (!container) return;

        container.innerHTML = '';
        const chapter = GameData.chapters[this.currentChapter];

        for (let i = 0; i < chapter.levels; i++) {
            const isUnlocked = Game.isLevelUnlocked(this.currentChapter, i);
            const isCleared = Game.isLevelCleared(this.currentChapter, i);

            const card = document.createElement('div');
            card.className = `level-card ${!isUnlocked ? 'locked' : ''} ${isCleared ? 'completed' : ''}`;

            const powerMult = Utils.getBotPowerMultiplier(this.currentChapter, i);
            const powerPercent = Math.round(powerMult * 100);

            card.innerHTML = `
                <div class="level-name">Ải ${i + 1}</div>
                <div class="level-info">
                    Sức mạnh: ${powerPercent}%
                </div>
                <div class="level-status">
                    <span>Phần thưởng: 10⭐ 50💎 100⚡</span>
                    <span class="${isCleared ? 'status-cleared' : isUnlocked ? 'status-current' : 'status-locked'}">
                        ${isCleared ? 'Đã Vượt Qua' : isUnlocked ? 'Sẵn Sàng' : 'Đang Khoá'}
                    </span>
                </div>
            `;

            if (isUnlocked) {
                card.addEventListener('click', () => {
                    this.currentLevel = i;
                    Game.state.selectedTeam = [];
                    CharacterManager.renderTeamSelect();
                    Game.showScreen('teamScreen');
                });
            }

            container.appendChild(card);
        }
    },

    /**
     * Tạo đội bot cho ải
     */
    createEnemyTeam() {
        const powerMult = Utils.getBotPowerMultiplier(this.currentChapter, this.currentLevel);
        const enemies = [];
        
        // Số lượng bot: 1-3 tùy độ khó
        const totalLevelIndex = this.currentChapter * 10 + this.currentLevel;
        let enemyCount = 1;
        if (totalLevelIndex >= 3) enemyCount = 2;
        if (totalLevelIndex >= 7) enemyCount = 3;

        // Các loại bot có thể xuất hiện
        const types = ['ATK', 'DEF', 'SKL'];
        
        for (let i = 0; i < enemyCount; i++) {
            // Chọn loại bot ngẫu nhiên, đảm bảo đa dạng
            let botType;
            if (i === 0 && totalLevelIndex < 5) {
                botType = 'ATK'; // Ải đầu dễ hơn
            } else {
                botType = types[Utils.randomInt(0, types.length - 1)];
            }
            
            const botData = createBotData(botType, powerMult);
            enemies.push(this.createBattleUnit(botData, false));
        }

        return enemies;
    },

    /**
     * Tạo đơn vị chiến đấu từ dữ liệu nhân vật
     */
    createBattleUnit(charData, isPlayer) {
        const stats = charData.currentStats || charData.baseStats;
        const maxHp = stats.hp;
        
        return {
            id: charData.instanceId || charData.id,
            data: charData,
            name: charData.name,
            type: charData.type,
            icon: charData.icon,
            isPlayer: isPlayer,
            isBot: charData.isBot || false,
            
            // Chỉ số chiến đấu
            maxHp: maxHp,
            currentHp: maxHp,
            atk: stats.atk,
            def: stats.def,
            spd: stats.spd,
            maxEn: stats.en,
            currentEn: Math.floor(stats.en / 2), // Bắt đầu với 1/2 EN
            
            // Trạng thái
            isDead: false,
            effects: [], // Danh sách hiệu ứng
            buffs: [],   // Buff chỉ số
            
            // Theo dõi riêng cho từng nhân vật
            turnCount: 0,
            vegitoShieldTriggered: false,
            omegaFirstTurn: true
        };
    },

    /**
     * Tạo đội người chơi từ danh sách đã chọn
     */
    createPlayerTeam() {
        const team = [];
        Game.state.selectedTeam.forEach(instanceId => {
            const char = Game.state.characters[instanceId];
            if (char) {
                team.push(this.createBattleUnit(char, true));
            }
        });
        return team;
    },

    /**
     * Bắt đầu trận đấu
     */
    startBattle() {
        if (Game.state.selectedTeam.length === 0) {
            UI.showMessage('Vui lòng chọn ít nhất 1 nhân vật!', 'Lỗi');
            return;
        }

        const playerTeam = this.createPlayerTeam();
        const enemyTeam = this.createEnemyTeam();

        BattleSystem.init({
            playerTeam,
            enemyTeam,
            chapterIndex: this.currentChapter,
            levelIndex: this.currentLevel,
            stageInfo: `Chương ${this.currentChapter + 1} - Ải ${this.currentLevel + 1}`
        });

        Game.showScreen('battleScreen');
    }
};
