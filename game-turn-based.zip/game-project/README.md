# Chiến Thuật Turn-Based

Game chiến thuật lượt chơi (Turn-Based) được xây dựng bằng HTML, CSS và JavaScript thuần. Không cần cài đặt, chỉ cần mở file `index.html` trong trình duyệt là có thể chơi.

## 🎮 Tính Năng Chính

### Hệ thống Nhân Vật
- **5 nhân vật**: Nhà Lữ Hành (mặc định), Madara (Lục Đạo), Omega Shenron, Vegito, Whis
- **3 loại**: ATK (Tấn Công), DEF (Phòng Thủ), SKL (Kỹ Năng)
- **Nâng cấp**: Tối đa LV 220, mở khoá Bị động & Thần Chú theo các mốc level
- **Chỉ số**: HP, ATK, DEF, SPD, EN (Năng lượng)

### Hệ thống Chiến Đấu
- **Đội hình**: 3 nhân vật
- **Thứ tự đánh**: Dựa trên chỉ số SPD
- **Quản lý EN**: Đánh thường hồi EN, kỹ năng chủ động tiêu tốn toàn bộ EN
- **Hiệu ứng trạng thái**: Rực lửa, Chảy máu, Chảy máu+, Khiên, Huyết kích, Thiên Mệnh, Bảo Vệ, Suy Giảm, Tăng ATK...
- **Bạo kích**: 18% mặc định, x3 sát thương

### Đấu Ải
- **3 chương**, mỗi chương 10 ải (tổng 30 ải)
- Độ khó tăng: +15% mỗi ải, +40% mỗi chương
- Phần thưởng: Ánh Sao, Kim Cương, VPNC, Kinh nghiệm
- Phần thưởng tăng 20% mỗi 5 level người chơi

### Hệ thống Khác
- **Giftcode**: Nhập mã nhận quà
- **Lưu dữ liệu**: Tự động lưu trên trình duyệt (localStorage)
- **Đặt lại**: Xóa toàn bộ dữ liệu

## 📁 Cấu Trúc Dự Án

```
game-project/
├── index.html              # Trang chủ, giao diện chính
├── css/
│   ├── main.css            # Style chung, màn hình chính
│   ├── battle.css          # Style màn hình chiến đấu
│   └── popup.css           # Style các popup
├── js/
│   ├── utils.js            # Hàm tiện ích, công thức tính toán
│   ├── data.js             # Dữ liệu nhân vật, giftcode, cấu hình
│   ├── game.js             # Core game, lưu dữ liệu, khởi tạo
│   ├── character.js        # Quản lý nhân vật, nâng cấp
│   ├── stage.js            # Quản lý đấu ải, tạo bot
│   ├── battle.js           # Logic chiến đấu Turn-Based
│   └── ui.js               # Giao diện, sự kiện, popup
└── README.md               # Tài liệu này
```

## 🚀 Cách Chạy

1. Tải toàn bộ thư mục `game-project` về máy
2. Mở file `index.html` bằng trình duyệt (Chrome, Firefox, Edge, Safari...)
3. Bắt đầu chơi!

## 📦 Đưa Lên GitHub

1. Tạo repository mới trên GitHub
2. Upload toàn bộ nội dung thư mục `game-project` lên repository
3. Kích hoạt GitHub Pages trong Settings → Pages
4. Game sẽ có thể chơi trực tiếp qua link GitHub Pages

## 🎁 Giftcode Hiện Có

| Mã | Phần thưởng |
|---|---|
| TANTHU001 | 500 Ánh Sao |
| TANTHU002 | 500 Ánh Sao |
| TANTHU003 | 500 Ánh Sao |
| TFJIKOKDAB | 299 Kim Cương |
| TRUNGTHUVV | 4000 Ánh Sao |
| TRUNGTHU2026 | 4000 Ánh Sao |

## ⚙️ Công Thức Chính

- **Phòng thủ**: Mỗi 5 DEF giảm 0.5% sát thương nhận vào
- **EXP lên level**: Level 1→2 cần 100 EXP, tăng 22% theo level
- **EXP từ ải**: Ải 1 nhận 500 EXP, tăng 25% theo ải
- **Chi phí nâng cấp**: 100 VPNC + 800 Vàng, tăng 5% mỗi level
- **Phần thưởng**: Tăng 20% mỗi 5 level người chơi
- **Sức mạnh bot**: Cơ bản yếu 30% tướng chuẩn, +15%/ải, +40%/chương

## 🛠️ Thêm Nhân Vật Mới

Để thêm nhân vật mới, chỉnh sửa file `js/data.js`, thêm vào object `GameData.characters` theo định dạng mẫu có sẵn.

## 📝 Ghi Chú

- Dữ liệu game được lưu cục bộ trên trình duyệt. Xóa bộ nhớ trình duyệt sẽ mất tiến độ.
- Game hiện tại chưa có hệ thống đăng nhập, chỉ chơi đơn.
- Cửa hàng hiện chưa hoạt động, sẽ cập nhật trong các phiên bản sau.
